package com.common.common;

public final class IConstant
	{
		static public String	dashboardJsp			= "dashboard";
		static public String	footerJSP					= "Footer";
		static public String	forgotpasswordJSP	= "forgotpassword";
		static public String	headerJSP					= "Header";
		static public String	loginJSP					= "login";
		static public String	profilJsp				= "profil";
		static public String	registerJSP				= "register";
		static public String	trainingJSP				= "training";
	}
