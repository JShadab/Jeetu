package com.lawrence.ui;

import com.lawrence.entity.UserDetailsEntity;
import com.lawrence.repository.UserDetailsRepository;
import com.lawrence.utils.AuthService;
import com.lawrence.utils.SharedData;
import com.lawrence.utils.UserService;
import com.vaadin.navigator.View;
import com.vaadin.ui.Alignment;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Notification;
import com.vaadin.ui.Panel;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;

public class LoginUI extends VerticalLayout implements View {

	public LoginUI(UserDetailsRepository repository) {
		FormLayout formLayout = new FormLayout();
		formLayout.setSpacing(true);

		TextField txtEmail = new TextField("Email");
		TextField txtPassword = new PasswordField("Password");

		Button btnLogin = new Button("Login");
		btnLogin.addClickListener(new ClickListener() {

			@Override
			public void buttonClick(ClickEvent event) {
				// Notification.show("Login button clicked");

				String email = txtEmail.getValue();
				String password = txtPassword.getValue();

				UserService.setUserDetailsRepository(repository);

				onLogin(email, password, true);
				/*
				 * UserDetailsEntity userDetails = repository.findByEmailAndPassword(email,
				 * password);
				 * 
				 * if (userDetails != null) {
				 * 
				 * SharedData.setUser(userDetails);
				 * 
				 * if (userDetails.isProfileUpdated()) {
				 * getUI().getNavigator().navigateTo("dashboard"); } else {
				 * getUI().getNavigator().navigateTo("profile"); }
				 * 
				 * } else {
				 * 
				 * Notification.show("Login failed"); }
				 */
			}
		});

		Button btnSignup = new Button("SignUp");
		btnSignup.addClickListener(new ClickListener() {

			@Override
			public void buttonClick(ClickEvent event) {
				// Notification.show("SignUp button clicked");

				getUI().getNavigator().navigateTo("signup");

				// reset UI Components
				txtEmail.setValue("");
				txtPassword.setValue("");
			}
		});

		HorizontalLayout horizontalLayout = new HorizontalLayout();

		horizontalLayout.addComponent(btnLogin);
		horizontalLayout.addComponent(btnSignup);

		formLayout.addComponents(txtEmail, txtPassword, horizontalLayout);

		// Panel
		Panel loginPanel = new Panel("Peer Review System", formLayout);
		loginPanel.setWidth("450");
		loginPanel.setHeight("250");

		// Add Components

		addComponent(loginPanel);
		setComponentAlignment(loginPanel, Alignment.MIDDLE_CENTER);

	}

	private void onLogin(String username, String password, boolean rememberMe) {
		if (AuthService.login(username, password, rememberMe)) {
			MyUI ui = (MyUI) UI.getCurrent();
			ui.showPrivateComponent();
		} else {
			Notification.show("Invalid credentials (for demo use: admin/password)", Notification.Type.ERROR_MESSAGE);
		}
	}

}
