package com.lawrence.ui;

import java.util.ArrayList;
import java.util.List;

import com.lawrence.entity.UserDetailsEntity;
import com.lawrence.repository.UserDetailsRepository;
import com.lawrence.utils.SharedData;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;

@SpringComponent
@UIScope
public class ProfileUI extends VerticalLayout implements View {
	private TextField txtEmail;
	private TextField txtHeight;
	private TextField txtWeight;
	private ComboBox<String> cmbMotivation;
	private ComboBox<String> cmbBarrier;
	private ComboBox<String> cmbMemebership;
	private ComboBox<String> cmbLevel;

	/**
	 * Denpendency Injection. Enables us to make use of our Service Class.
	 */

	public ProfileUI(UserDetailsRepository repository) {

		// INITIAL SETUP
		setSpacing(true);
		// setMargin(true);

		// Header part
		Label lbHeader = new Label("Profile Form");
		lbHeader.setStyleName("h1");
		addComponent(lbHeader);

		FormLayout formLayout = new FormLayout();

		formLayout.setMargin(false);
		// formLayout.setWidth("700");
		// formLayout.addStyleName("light");
		addComponent(formLayout);

		txtEmail = new TextField("Email");
		txtEmail.setValue("JustJava");
		txtEmail.setReadOnly(true);
		formLayout.addComponent(txtEmail);

		txtHeight = new TextField("Enter your height in meter");
		txtHeight.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtHeight);

		txtWeight = new TextField("Enter your weight in Kg");
		txtWeight.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtWeight);

		/****************************************************/
		List<String> motivations = new ArrayList<>();
		motivations.add("I wish to improve my look");
		motivations.add("I wish to improve my leistung");
		motivations.add("I wish to improve my wohlbefinden");

		cmbMotivation = new ComboBox<>("Select Your Motivation");
		cmbMotivation.setRequiredIndicatorVisible(true);
		cmbMotivation.setItems(motivations);
		cmbMotivation.setWidth(300, Unit.PIXELS);
		formLayout.addComponent(cmbMotivation);

		/****************************************************/
		List<String> barriers = new ArrayList<>();
		barriers.add("Time Factor");
		barriers.add("I lack motivation");
		barriers.add("No Barrier, I am willing");

		cmbBarrier = new ComboBox<>("Select Your Barrier");
		cmbBarrier.setRequiredIndicatorVisible(true);
		cmbBarrier.setItems(barriers);
		cmbBarrier.setWidth(200, Unit.PIXELS);
		formLayout.addComponent(cmbBarrier);

		/****************************************************/
		List<String> memeberships = new ArrayList<>();
		memeberships.add("Free");
		memeberships.add("Paid");

		cmbMemebership = new ComboBox<>("Select Membership Plan");
		cmbMemebership.setRequiredIndicatorVisible(true);
		cmbMemebership.setItems(barriers);
		formLayout.addComponent(cmbMemebership);

		/****************************************************/

		List<String> levels = new ArrayList<>();
		levels.add("Beginner");
		levels.add("Intermediate");
		levels.add("Expert");

		cmbLevel = new ComboBox<>("Select Your Level");
		cmbLevel.setRequiredIndicatorVisible(true);
		cmbLevel.setItems(levels);
		formLayout.addComponent(cmbLevel);

		Button btnSubmit = new Button("Submit Profile");
		formLayout.addComponent(btnSubmit);

		btnSubmit.addClickListener(new ClickListener() {

			@Override
			public void buttonClick(ClickEvent event) {

				MyUI ui = (MyUI) getUI();

				UserDetailsEntity currentUser = ui.getCurrentUser();

				/************ Height Validation *****************/
				String heightStr = txtHeight.getValue();
				if (heightStr == null || heightStr.isEmpty()) {
					Notification.show("Please enter height");
					return;
				}
				float height = 0;
				try {
					height = Float.parseFloat(heightStr);
				} catch (NumberFormatException e) {
					Notification.show("Please enter valid height");
					return;
				}

				/************ Width Validation *****************/

				String widthStr = txtWeight.getValue();

				if (widthStr == null || widthStr.isEmpty()) {
					Notification.show("Please enter width");
					return;
				}
				float width = 0;
				try {
					height = Float.parseFloat(widthStr);
				} catch (NumberFormatException e) {
					Notification.show("Please enter valid width");
					return;
				}

				String motivation = cmbMotivation.getSelectedItem().get();
				String level = cmbLevel.getSelectedItem().get();
				String barrier = cmbBarrier.getSelectedItem().get();
				String membership = cmbMemebership.getSelectedItem().get();

				if (motivation == null || motivation.isEmpty()) {
					Notification.show("Please enter motivation");
					return;
				} else if (level == null || level.isEmpty()) {
					Notification.show("Please enter level");
					return;
				} else if (barrier == null || barrier.isEmpty()) {
					Notification.show("Please enter barrier");
					return;
				} else if (membership == null || membership.isEmpty()) {
					Notification.show("Please enter membership");
					return;
				}

				currentUser.setHeight(height);
				currentUser.setWeight(width);
				currentUser.setMotivation(motivation);
				currentUser.setLevel(level);
				currentUser.setBarrier(barrier);
				currentUser.setMembership(membership);

				currentUser.setProfileUpdated(true);

				repository.save(currentUser);

				getUI().getNavigator().navigateTo("dashboard");
			}
		});
		populateValues();
	}

	@Override
	public void enter(ViewChangeEvent event) {
		View.super.enter(event);

		populateValues();
	}

	void populateValues() {

		UserDetailsEntity user = SharedData.getUser();

		if (user != null) {
			txtEmail.setValue(user.getEmail());
			txtHeight.setValue(String.valueOf(user.getHeight()));
			txtWeight.setValue(String.valueOf(user.getWeight()));
			cmbBarrier.setSelectedItem(user.getBarrier());
			cmbLevel.setSelectedItem(user.getLevel());
			cmbMemebership.setSelectedItem(user.getMembership());
			cmbMotivation.setSelectedItem(user.getMotivation());
		}
	}

}
