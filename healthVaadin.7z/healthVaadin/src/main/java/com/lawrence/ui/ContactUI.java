package com.lawrence.ui;

import java.util.ArrayList;
import java.util.List;

import com.lawrence.entity.UserDetailsEntity;
import com.lawrence.repository.UserDetailsRepository;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextArea;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;

@SpringComponent
@UIScope
public class ContactUI extends VerticalLayout implements View {
	/**
	 * Denpendency Injection. Enables us to make use of our Service Class.
	 */

	public ContactUI(UserDetailsRepository repository) {

		// INITIAL SETUP
		setSpacing(true);
		// setMargin(true);

		// Header part
		Label lbHeader = new Label("Contact Form");
		lbHeader.setStyleName("h1");
		addComponent(lbHeader);

		FormLayout formLayout = new FormLayout();

		formLayout.setMargin(false);
		// formLayout.setWidth("700");
		// formLayout.addStyleName("light");
		addComponent(formLayout);
		
		TextArea txtMesage=new TextArea("Write message...");
		
		txtMesage.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtMesage);

		

		Button btnSend = new Button("Send");
		formLayout.addComponent(btnSend);

		btnSend.addClickListener(new ClickListener() {

			@Override
			public void buttonClick(ClickEvent event) {

				Notification.show("ToDo: Message Sent")

				getUI().getNavigator().navigateTo("dashboard");
			}
		});

	}

}
