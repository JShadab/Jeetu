package com.lawrence.ui;

import org.springframework.beans.factory.annotation.Autowired;

import com.lawrence.entity.UserDetailsEntity;
import com.lawrence.repository.UserDetailsRepository;
import com.lawrence.utils.AuthService;
import com.vaadin.annotations.Theme;
import com.vaadin.navigator.Navigator;
import com.vaadin.server.VaadinRequest;
import com.vaadin.spring.annotation.SpringUI;
import com.vaadin.ui.UI;

@SpringUI
@Theme("valo")
public class MyUI extends UI {

	private final UserDetailsRepository userDetailsRepository;
	private Navigator navigator;

	@Autowired
	public MyUI(UserDetailsRepository userDetailsRepository) {
		this.userDetailsRepository = userDetailsRepository;
	}

	@Override
	protected void init(VaadinRequest request) {

		navigator = new Navigator(this, this);

		// Login
		navigator.addView("login", new LoginUI(userDetailsRepository));

		// Sign Up
		navigator.addView("signup", new SignUpFormUI(userDetailsRepository));

		// Student/Teacher DashboardUI
		navigator.addView("dashboard", new DashboardUI(userDetailsRepository));

		// Profile
		navigator.addView("profile", new ProfileUI(userDetailsRepository));

		// Contact
		navigator.addView("contact", new ContactUI(userDetailsRepository));

		// Begin login view
		if (!AuthService.isAuthenticated()) {
			showPublicComponent();
		} else {
			showPrivateComponent();
		}

	}

	public void showPublicComponent() {// Begin login view
		navigator.navigateTo("login");
	}

	public void showPrivateComponent() {
		navigator.navigateTo("dashboard");
	}

	static final String CURRENT_USER = "current_user";

	public UserDetailsEntity getCurrentUser() {

		return (UserDetailsEntity) getUI().getSession().getAttribute(CURRENT_USER);

	}

	public void putCurrentUser(UserDetailsEntity user) {
		getUI().getSession().setAttribute(CURRENT_USER, user);
	}
}
