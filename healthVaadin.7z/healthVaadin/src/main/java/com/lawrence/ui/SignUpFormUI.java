package com.lawrence.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.lawrence.entity.UserDetailsEntity;
import com.lawrence.repository.UserDetailsRepository;
import com.vaadin.navigator.View;
import com.vaadin.spring.annotation.SpringComponent;
import com.vaadin.spring.annotation.UIScope;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.Button.ClickListener;
import com.vaadin.ui.ComboBox;
import com.vaadin.ui.FormLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.PasswordField;
import com.vaadin.ui.TextField;
import com.vaadin.ui.VerticalLayout;

@SpringComponent
@UIScope
public class SignUpFormUI extends VerticalLayout implements View {
	/**
	 * Denpendency Injection. Enables us to make use of our Service Class.
	 */

	public SignUpFormUI(UserDetailsRepository repository) {

		// INITIAL SETUP
		setSpacing(true);
		// setMargin(true);

		// Header part
		Label lbHeader = new Label("SignUp Form");
		lbHeader.setStyleName("h1");
		addComponent(lbHeader);

		FormLayout formLayout = new FormLayout();

		formLayout.setMargin(false);
		// formLayout.setWidth("700");
		// formLayout.addStyleName("light");
		addComponent(formLayout);

		TextField txtUserName = new TextField("User Name");
		txtUserName.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtUserName);

		TextField txtEmail = new TextField("Email");
		txtEmail.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtEmail);

		TextField txtPassword = new PasswordField("Password");
		txtPassword.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtPassword);

		TextField txtFirstName = new TextField("First Name");
		txtFirstName.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtFirstName);

		TextField txtLastName = new TextField("Last Name");
		txtLastName.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtLastName);

		List<String> genders = new ArrayList<>();
		genders.add("Male");
		genders.add("Female");
		genders.add("Other");

		ComboBox<String> cmbGender = new ComboBox<>("Gender");
		cmbGender.setRequiredIndicatorVisible(true);
		cmbGender.setItems(genders);
		formLayout.addComponent(cmbGender);

		TextField txtAge = new TextField("Age");
		txtAge.setRequiredIndicatorVisible(true);
		formLayout.addComponent(txtAge);

		Button btnSignup = new Button("SignUp");
		formLayout.addComponent(btnSignup);

		btnSignup.addClickListener(new ClickListener() {

			@Override
			public void buttonClick(ClickEvent event) {

				UserDetailsEntity userDetailsEntity = new UserDetailsEntity();

				String ageStr = txtAge.getValue();
				String email = txtEmail.getValue();
				String firstName = txtFirstName.getValue();
				String lastName = txtLastName.getValue();
				String password = txtPassword.getValue();
				String gender = cmbGender.getSelectedItem().get();
				String userName = txtUserName.getValue();

				if (ageStr == null || ageStr.isEmpty()) {
					Notification.show("Please enter age.");
					return;
				} else if (email == null || email.isEmpty()) {
					Notification.show("Please enter email.");
					return;
				} else if (firstName == null || firstName.isEmpty()) {
					Notification.show("Please enter firstName.");
					return;
				} else if (lastName == null || lastName.isEmpty()) {
					Notification.show("Please enter last name.");
					return;
				} else if (password == null || password.isEmpty()) {
					Notification.show("Please enter password.");
					return;
				} else if (gender == null || gender.isEmpty()) {
					Notification.show("Please enter gender.");
					return;
				} else if (userName == null || userName.isEmpty()) {
					Notification.show("Please enter user name.");
					return;
				}

				/***************** Email Validation ******************/
				String emailRegex = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
				Pattern emailPattern = Pattern.compile(emailRegex, Pattern.CASE_INSENSITIVE);
				Matcher emailMatcher = emailPattern.matcher(email);
				boolean isValidEmail = emailMatcher.find();
				if (isValidEmail) {

					Notification.show(email + " is not in proper format! please enter valid Email");
					return;
				}

				/**************** Password Validation ********************/

				String passwordRegex = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$";
				Pattern passwordPattern = Pattern.compile(passwordRegex);
				Matcher passwordMatcher = passwordPattern.matcher(password);

				boolean isValidPassword = passwordMatcher.find();

				if (isValidPassword) {

					Notification.show(email + "Password should contain Atleast one number,one small character,"
							+ "one capital character and minimum length should be 8");
					return;
				}

				/******************* Age Validation *********************/

				try {

					Integer.parseInt(ageStr);
				} catch (NumberFormatException e) {

					Notification.show("Please enter numeric value for age");
					return;

				}

				userDetailsEntity.setAge(ageStr);
				userDetailsEntity.setEmail(email);
				userDetailsEntity.setFirstName(firstName);
				userDetailsEntity.setGender(gender);
				userDetailsEntity.setLastName(lastName);
				userDetailsEntity.setPassword(password);
				userDetailsEntity.setUserName(userName);

				repository.save(userDetailsEntity);

				Notification.show("Registeration Successful");

				// Redirect to login view
				getUI().getNavigator().navigateTo("login");
				/*
				 * txtAge.setValue(""); txtEmail.setValue(""); txtFirstName.setValue("");
				 * txtGender.setValue(""); txtLastName.setValue(""); txtPassword.setValue("");
				 * txtUserName.setValue("");
				 */

			}
		});

	}

}
