package com.lawrence.ui;

import com.lawrence.repository.UserDetailsRepository;
import com.lawrence.utils.AuthService;
import com.lawrence.utils.Days;
import com.vaadin.navigator.Navigator;
import com.vaadin.navigator.View;
import com.vaadin.navigator.ViewChangeListener.ViewChangeEvent;
import com.vaadin.server.ExternalResource;
import com.vaadin.ui.Embedded;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.VerticalLayout;

public class DashboardUI extends VerticalLayout implements View {

	public DashboardUI(UserDetailsRepository repository) {
		MenuBar menuBar = new MenuBar();
		addComponent(menuBar);

		Embedded e = new Embedded();
		e.setAlternateText("Vaadin Eclipse Quickstart video");
		e.setMimeType("application/x-shockwave-flash");
		e.setParameter("allowFullScreen", "true");
		e.setWidth("320px");
		e.setHeight("265px");
		e.setVisible(false);

		addComponent(e);
		// Define a common menu command for all the menu items.
		MenuBar.Command mycommand = new MenuBar.Command() {
			public void menuSelected(MenuItem selectedItem) {

				Navigator navigator = getUI().getNavigator();

				switch (selectedItem.getText()) {

				case "Profile": {
					navigator.navigateTo("profile");
					break;
				}
				case "Training Plan": {
					// navigator.navigateTo("profile");
					break;
				}
				case "Logout": {
					// navigator.navigateTo("profile");
					logout();
					break;
				}

				case "Contact": {
					navigator.navigateTo("contact");
					break;
				}

				default:
					break;
				}
			}
		};

		MenuBar.Command trainingCMD = new MenuBar.Command() {
			public void menuSelected(MenuItem selectedItem) {

				Days day = Days.valueOf(selectedItem.getText().toUpperCase());

				e.setVisible(true);

				switch (day) {

				case SUNDAY: {
					e.setSource(new ExternalResource("http://www.youtube.com/v/meXvxkn1Y_8&hl=en_US&fs=1&"));
					break;
				}
				case MONDAY: {

					e.setSource(new ExternalResource("http://www.youtube.com/v/meXvxkn1Y_8&hl=en_US&fs=1&"));
					break;
				}
				case WEDNESDAY: {
					e.setSource(new ExternalResource("http://www.youtube.com/v/meXvxkn1Y_8&hl=en_US&fs=1&"));
					break;
				}
				case THURSDAY: {
					e.setSource(new ExternalResource("http://www.youtube.com/v/meXvxkn1Y_8&hl=en_US&fs=1&"));
					break;
				}
				case FRIDAY: {
					e.setSource(new ExternalResource("http://www.youtube.com/v/meXvxkn1Y_8&hl=en_US&fs=1&"));
					break;
				}
				case SATURDAY: {
					e.setSource(new ExternalResource("http://www.youtube.com/v/meXvxkn1Y_8&hl=en_US&fs=1&"));

					break;
				}

				default:
					e.setVisible(false);
					break;
				}
			}
		};

		MenuItem menuTraining = menuBar.addItem("Training Plan", null, null);
		menuTraining.addItem(Days.SUNDAY.toString(), trainingCMD);
		menuTraining.addItem(Days.MONDAY.toString(), trainingCMD);
		menuTraining.addItem(Days.TUESDAY.toString(), trainingCMD);
		menuTraining.addItem(Days.WEDNESDAY.toString(), trainingCMD);
		menuTraining.addItem(Days.THURSDAY.toString(), trainingCMD);
		menuTraining.addItem(Days.FRIDAY.toString(), trainingCMD);
		menuTraining.addItem(Days.SATURDAY.toString(), trainingCMD);

		MenuItem menuProfile = menuBar.addItem("Profile", null, mycommand);
		MenuItem menuContact = menuBar.addItem("Contact", null, mycommand);
		MenuItem menuLogout = menuBar.addItem("Logout", null, mycommand);
	}

	private void logout() {

		AuthService.logOut();
		// Close the VaadinServiceSession
		// getUI().getSession().close();

		// Invalidate underlying session instead if login info is stored there
		// VaadinService.getCurrentRequest().getWrappedSession().invalidate();

		// Redirect to avoid keeping the removed UI open in the browser
		// getUI().getNavigator().navigateTo("login");
	}

}
