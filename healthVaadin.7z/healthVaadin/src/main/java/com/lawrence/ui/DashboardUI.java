package com.lawrence.ui;

import com.lawrence.repository.UserDetailsRepository;
import com.vaadin.navigator.Navigator;
import com.vaadin.navigator.View;
import com.vaadin.ui.MenuBar;
import com.vaadin.ui.MenuBar.MenuItem;
import com.vaadin.ui.Notification;
import com.vaadin.ui.VerticalLayout;

public class DashboardUI extends VerticalLayout implements View {

	public DashboardUI(UserDetailsRepository repository) {
		MenuBar menuBar = new MenuBar();
		addComponent(menuBar);
		// Define a common menu command for all the menu items.
		MenuBar.Command mycommand = new MenuBar.Command() {
			public void menuSelected(MenuItem selectedItem) {
				Notification.show("Ordered a " + selectedItem.getText() + " from menu.");

				// MyUI ui = (MyUI) getUI();

				// UserDetailsEntity currentUser = ui.getCurrentUser();

				Navigator navigator = getUI().getNavigator();

				switch (selectedItem.getText()) {

				case "Profile": {
					navigator.navigateTo("profile");
					break;
				}
				case "Training Plan": {
					// navigator.navigateTo("profile");
					break;
				}
				case "Logout": {
					// navigator.navigateTo("profile");
					logout();
					break;
				}

				case "Contact": {
					navigator.navigateTo("contact");
					break;
				}

				default:
					break;
				}
			}
		};

		MenuItem menuTraining = menuBar.addItem("Training Plan", null, null);
		menuTraining.addItem("Sunday", mycommand);
		menuTraining.addItem("Monday", mycommand);
		menuTraining.addItem("Tuesday", mycommand);
		menuTraining.addItem("Wednesday", mycommand);
		menuTraining.addItem("Thursday", mycommand);
		menuTraining.addItem("Friday", mycommand);
		menuTraining.addItem("Saturday", mycommand);

		MenuItem menuProfile = menuBar.addItem("Profile", null, mycommand);
		MenuItem menuContact = menuBar.addItem("Contact", null, mycommand);
		MenuItem menuLogout = menuBar.addItem("Logout", null, mycommand);
	}

	private void logout() {
		// Close the VaadinServiceSession
		getUI().getSession().close();

		// Invalidate underlying session instead if login info is stored there
		// VaadinService.getCurrentRequest().getWrappedSession().invalidate();

		// Redirect to avoid keeping the removed UI open in the browser
		getUI().getNavigator().navigateTo("login");
	}

}
