package com.lawrence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthVaadinApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthVaadinApplication.class, args);
	}
}
