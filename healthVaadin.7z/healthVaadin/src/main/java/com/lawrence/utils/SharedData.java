package com.lawrence.utils;

import com.lawrence.entity.UserDetailsEntity;

public class SharedData {
	
	
	private static  UserDetailsEntity user;
	
	public static UserDetailsEntity getUser() {
		return user;
	}
	
	public static void setUser(UserDetailsEntity user) {
		SharedData.user = user;
	}

}
