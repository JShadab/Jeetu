package com.lawrence.utils;

public enum Days {
	SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"), FRIDAY(
			"Friday"), SATURDAY("Sataurday");

	private String name;

	private Days(String name) {
		this.name = name;
	};

	@Override
	public String toString() {
		return name;
	}
	
	
}
