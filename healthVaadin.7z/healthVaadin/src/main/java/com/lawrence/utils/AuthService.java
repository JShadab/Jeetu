package com.lawrence.utils;
import com.vaadin.server.Page;
import com.vaadin.server.VaadinService;
import com.vaadin.server.VaadinSession;

import javax.servlet.http.Cookie;
import java.util.Arrays;
import java.util.Optional;

/**
 * @author Alejandro Duarte.
 */
public class AuthService {

    private static final String COOKIE_NAME = "remember-me";
    public static final String SESSION_EMAIL = "email";

    public static boolean isAuthenticated() {
        return VaadinSession.getCurrent().getAttribute(SESSION_EMAIL) != null || loginRememberedUser();
    }

    public static boolean login(String email, String password, boolean rememberMe) {
        if (UserService.isAuthenticUser(email, password)) {
            VaadinSession.getCurrent().setAttribute(SESSION_EMAIL, email);

            if (rememberMe) {
                rememberUser(email);
            }
            return true;
        }

        return false;
    }

    public static void logOut() {
        Optional<Cookie> cookie = getRememberMeCookie();
        if (cookie.isPresent()) {
            String id = cookie.get().getValue();
            UserService.removeRememberedUser(id);
            deleteRememberMeCookie();
        }

        VaadinSession.getCurrent().close();
        Page.getCurrent().setLocation("");
    }

    private static Optional<Cookie> getRememberMeCookie() {
        Cookie[] cookies = VaadinService.getCurrentRequest().getCookies();
        return Arrays.stream(cookies).filter(c -> c.getName().equals(COOKIE_NAME)).findFirst();
    }

    private static boolean loginRememberedUser() {
        Optional<Cookie> rememberMeCookie = getRememberMeCookie();

        if (rememberMeCookie.isPresent()) {
            String id = rememberMeCookie.get().getValue();
            String email = UserService.getRememberedUser(id);

            if (email != null) {
                VaadinSession.getCurrent().setAttribute(SESSION_EMAIL, email);
                return true;
            }
        }

        return false;
    }

    private static void rememberUser(String email) {
        String id = UserService.rememberUser(email);

        Cookie cookie = new Cookie(COOKIE_NAME, id);
        cookie.setPath("/");
        cookie.setMaxAge(60 * 60 * 24 * 30);
        VaadinService.getCurrentResponse().addCookie(cookie);
    }

    private static void deleteRememberMeCookie() {
        Cookie cookie = new Cookie(COOKIE_NAME, "");
        cookie.setPath("/");
        cookie.setMaxAge(0);
        VaadinService.getCurrentResponse().addCookie(cookie);
    }

}
