package com.lawrence.utils;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lawrence.repository.UserDetailsRepository;

/**
 */
@Service
public class UserService {

	static UserDetailsRepository userDetailsRepository;

	private static SecureRandom random = new SecureRandom();

	private static Map<String, String> rememberedUsers = new HashMap<>();

	@Autowired
	public static void setUserDetailsRepository(UserDetailsRepository userDetailsRepository) {
		UserService.userDetailsRepository = userDetailsRepository;
	}

	public static boolean isAuthenticUser(String email, String password) {
		return userDetailsRepository.findByEmailAndPassword(email, password) != null;
	}

	public static String rememberUser(String email) {
		String randomId = new BigInteger(130, random).toString(32);
		rememberedUsers.put(randomId, email);
		return randomId;
	}

	public static String getRememberedUser(String id) {
		return rememberedUsers.get(id);
	}

	public static void removeRememberedUser(String id) {
		rememberedUsers.remove(id);
	}

}