package com.lawrence.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.lawrence.entity.TrainingEntity;

/**
 * With MongoDb in picture you will not need it,this will do everything for you. There is nothing like select query in
 * mongodb. you see.so everything is inbuild.
 */
@Repository
public interface TrainingRepository extends MongoRepository <TrainingEntity, String>
	{		
		List<TrainingEntity> findTrainingByTrainingDayAndAgeAndGenderAndFitnessLevel(String trainingDay,String age,String gender,String fitnessLevel);		
	}
