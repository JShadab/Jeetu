package com.lawrence.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.lawrence.entity.UserDetailsEntity;

/**
 * With MongoDb in picture you will not need it,this will do everything for you.
 * There is nothing like select query in mongodb. you see.so everything is
 * inbuild.
 */
@Repository
public interface UserDetailsRepository extends MongoRepository<UserDetailsEntity, String> {

	UserDetailsEntity save(UserDetailsEntity userDetailsEntity);

	UserDetailsEntity findByEmailAndPassword(String email, String password);

	UserDetailsEntity findByEmail(String email);

}
