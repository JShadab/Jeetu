package com.lawrence.entity;

import org.springframework.data.annotation.Id;

/**
 * The major and only difference between DTO and Entity is that Entity is mapped to Database table and contains Database
 * information. DTO doesnot have that information, it acts just like supplier, so that controller does not know the
 * Database Details. For Security reasons, We dont want to expose our Table details to Controller layer because it
 * directly interacts with client.
 */

// Even if we don't have @Document annotation, mongodb creates a collection with the name of ProfileEnity.
public class ProfileEntity
	{
		@Id
		private String	userId;
		
		private int			age;
		private String	gender;
		private float		height;
		private float		weight;
		private String	motivation;
		private String	barrier;
		private String	fitnessLevel;
		private String	membership;
		
		public String getUserId()
			{
				return userId;
			}
			
		public void setUserId(String userId)
			{
				this.userId = userId;
			}
			
		public int getAge()
			{
				return age;
			}
			
		public void setAge(int age)
			{
				this.age = age;
			}
			
		public String getGender()
			{
				return gender;
			}
			
		public void setGender(String gender)
			{
				this.gender = gender;
			}
			
		public float getHeight()
			{
				return height;
			}
			
		public void setHeight(float height)
			{
				this.height = height;
			}
			
		public float getWeight()
			{
				return weight;
			}
			
		public void setWeight(float weight)
			{
				this.weight = weight;
			}
			
		public String getMotivation()
			{
				return motivation;
			}
			
		public void setMotivation(String motivation)
			{
				this.motivation = motivation;
			}
			
		public String getBarrier()
			{
				return barrier;
			}
			
		public void setBarrier(String barrier)
			{
				this.barrier = barrier;
			}
			
		public String getFitnessLevel()
			{
				return fitnessLevel;
			}
			
		public void setFitnessLevel(String fitnessLevel)
			{
				this.fitnessLevel = fitnessLevel;
			}
			
		public String getMembership()
			{
				return membership;
			}
			
		public void setMembership(String membership)
			{
				this.membership = membership;
			}
			
	}
	
// 1. Create Entity
// 2. Create DTO
// 3. Create Service Interface.
// 4. Create Service Implementation 
// 5. Create Contoller
// 6. Create DAO
// 7. Create DAO IMPL
// 8. Create populator
// 9. Create Repository
