package com.lawrence.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * The major and only difference between DTO and Entity is that Entity is mapped to Database table and contains Database
 * information. DTO doesnot have that information, it acts just like supplier, so that controller does not know the
 * Database Details. For Security reasons, We dont want to expose our Table details to Controller layer because it
 * directly interacts with client.
 */

@Document(collection = "training")
public class TrainingEntity
	{
		@Id
		private String	trainingId;
		
		private String	trainingName;
		private String	trainingTime;
		private String	trainingFileLocation;
		private String	trainingDay;
		private String	age;
		private String	gender;
		private String	fitnessLevel;
		
		public String getTrainingId()
			{
				return trainingId;
			}
			
		public void setTrainingId(String trainingId)
			{
				this.trainingId = trainingId;
			}
			
		public String getTrainingName()
			{
				return trainingName;
			}
			
		public void setTrainingName(String trainingName)
			{
				this.trainingName = trainingName;
			}
			
		public String getTrainingTime()
			{
				return trainingTime;
			}
			
		public void setTrainingTime(String trainingTime)
			{
				this.trainingTime = trainingTime;
			}
			
		public String getTrainingFileLocation()
			{
				return trainingFileLocation;
			}
			
		public void setTrainingFileLocation(String trainingFileLocation)
			{
				this.trainingFileLocation = trainingFileLocation;
			}
			
		public String getAge()
			{
				return age;
			}
			
		public void setAge(String age)
			{
				this.age = age;
			}
			
		public String getGender()
			{
				return gender;
			}
			
		public void setGender(String gender)
			{
				this.gender = gender;
			}
			
		public String getFitnessLevel()
			{
				return fitnessLevel;
			}
			
		public void setFitnessLevel(String fitnessLevel)
			{
				this.fitnessLevel = fitnessLevel;
			}
			
		public String getTrainingDay()
			{
				return trainingDay;
			}
			
		public void setTrainingDay(String trainingDay)
			{
				this.trainingDay = trainingDay;
			}
	}
