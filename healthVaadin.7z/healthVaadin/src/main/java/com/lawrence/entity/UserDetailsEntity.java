package com.lawrence.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * The major and only difference between DTO and Entity is that Entity is mapped
 * to Database table and contains Database information. DTO doesnot have that
 * information, it acts just like supplier, so that controller does not know the
 * Database Details. For Security reasons, We dont want to expose our Table
 * details to Controller layer because it directly interacts with client.
 */

@Document(collection = "userDetails")
public class UserDetailsEntity {

	@Id
	private String userId;

	private String userName;
	private String password;
	private String email;
	private String firstName;
	private String lastName;
	private String gender;
	private String age;

	private float height;
	private float weight;

	private String barrier;
	private String motivation;
	private String membership;
	private String level;

	private boolean isProfileUpdated;

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public String getBarrier() {
		return barrier;
	}

	public void setBarrier(String barrier) {
		this.barrier = barrier;
	}

	public String getMotivation() {
		return motivation;
	}

	public void setMotivation(String motivation) {
		this.motivation = motivation;
	}

	public String getMembership() {
		return membership;
	}

	public void setMembership(String membership) {
		this.membership = membership;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public boolean isProfileUpdated() {
		return isProfileUpdated;
	}
	
	public void setProfileUpdated(boolean isProfileUpdated) {
		this.isProfileUpdated = isProfileUpdated;
	}
}
